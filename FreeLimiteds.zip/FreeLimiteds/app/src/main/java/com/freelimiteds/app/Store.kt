package com.freelimiteds.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Store {
    private fun p(c: Context) = c.getSharedPreferences("free", Context.MODE_PRIVATE)

    fun seen(c: Context): MutableSet<String> = HashSet(p(c).getStringSet("seen", emptySet())!!)

    fun addSeen(c: Context, ids: Collection<Long>) {
        val s = seen(c)
        ids.forEach { s.add(it.toString()) }
        p(c).edit().putStringSet("seen", s).apply()
    }

    fun seeded(c: Context) = p(c).getBoolean("seeded", false)
    fun setSeeded(c: Context) = p(c).edit().putBoolean("seeded", true).apply()

    fun enabled(c: Context) = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()
}

object AppLog {
    private val lines = ArrayDeque<String>()
    @Volatile var listener: ((String) -> Unit)? = null

    @Synchronized
    fun add(s: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        lines.addLast("$t  $s")
        while (lines.size > 200) lines.removeFirst()
        listener?.invoke(lines.joinToString("\n"))
    }

    @Synchronized
    fun text(): String = lines.joinToString("\n")
}
