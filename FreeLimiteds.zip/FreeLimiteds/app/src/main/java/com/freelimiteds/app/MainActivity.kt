package com.freelimiteds.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var log: TextView
    private lateinit var toggle: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val title = TextView(this).apply { text = "Бесплатные лимитки"; textSize = 22f }
        toggle = Button(this)
        val check = Button(this).apply { text = "Проверить сейчас" }
        log = TextView(this).apply { textSize = 12f; setTextIsSelectable(true) }
        val scroll = ScrollView(this).apply { addView(log) }

        root.addView(title)
        root.addView(toggle)
        root.addView(check)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        toggle.setOnClickListener {
            if (Store.enabled(this)) {
                Store.setEnabled(this, false)
                stopService(Intent(this, FreeLimitedService::class.java))
            } else {
                Store.setEnabled(this, true)
                ContextCompat.startForegroundService(this, Intent(this, FreeLimitedService::class.java))
            }
            refresh()
        }

        check.setOnClickListener {
            Thread {
                try {
                    val r = Sources.fetch(true)
                    AppLog.add("Сейчас найдено бесплатных лимиток: ${r.items.size}")
                    r.items.forEach { AppLog.add("• ${it.name} [${it.source}] ${it.url}") }
                    r.errors.forEach { AppLog.add("⚠ $it") }
                } catch (e: Exception) {
                    AppLog.add("Ошибка: ${e.message}")
                }
            }.start()
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        refresh()
    }

    private fun refresh() {
        toggle.text = if (Store.enabled(this)) "Остановить" else "Запустить"
    }

    override fun onResume() {
        super.onResume()
        log.text = AppLog.text()
        AppLog.listener = { t -> runOnUiThread { log.text = t } }
        refresh()
    }

    override fun onPause() {
        AppLog.listener = null
        super.onPause()
    }
}
