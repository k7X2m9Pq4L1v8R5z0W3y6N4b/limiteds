package com.freelimiteds.app

import android.app.Service
import android.content.Intent
import android.os.IBinder

class FreeLimitedService : Service() {
    @Volatile private var running = false
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifier.ensureChannels(this)
        startForeground(1, Notifier.foreground(this))
        if (!running) {
            running = true
            worker = Thread { loop() }.also { it.start() }
            AppLog.add("Сервис запущен")
        }
        return START_STICKY
    }

    private fun loop() {
        var tick = 0
        var backoff = 0 // секунд паузы после 429 от Rolimons: 60 -> 120 -> 240 -> 300
        while (running) {
            var sleepMs = 20_000L
            var limited = -1
            try {
                val res = Sources.fetch(tick)
                if (tick == 0 || tick % 15 == 0) res.info.forEach { AppLog.add(it) }
                res.errors.forEach { AppLog.add("⚠ $it") }
                if (res.rateLimitedSec >= 0) limited = res.rateLimitedSec

                val seen = Store.seen(this)
                val fresh = res.items.filter { it.id.toString() !in seen }

                if (!Store.seeded(this)) {
                    // Первый запуск: запоминаем всё, что уже есть, без уведомлений
                    if (res.rolimonsAll) {
                        Store.addSeen(this, fresh.map { it.id })
                        Store.setSeeded(this)
                        AppLog.add("Первый запуск: запомнил ${fresh.size} уже существующих предметов")
                    }
                } else if (fresh.isNotEmpty()) {
                    val done = mutableListOf<Long>()
                    for (item in fresh.take(8)) {
                        try {
                            val ready = if (item.needsCheck) Sources.resolve(item) else item
                            if (ready != null) {
                                Notifier.notifyItem(this, ready)
                                AppLog.add("🆓 НОВАЯ: ${ready.name} ${ready.extra} ${ready.url}")
                            }
                            done += item.id
                            if (item.needsCheck) Thread.sleep(1500)
                        } catch (e: RateLimitException) {
                            limited = maxOf(limited, e.retryAfterSec)
                            break
                        } catch (e: InterruptedException) {
                            return
                        } catch (e: Exception) {
                            AppLog.add("⚠ #${item.id}: ${e.message}")
                            done += item.id
                        }
                    }
                    Store.addSeen(this, done)
                }

                if (limited >= 0) {
                    backoff = if (backoff == 0) 60 else minOf(backoff * 2, 300)
                    val wait = maxOf(backoff, limited)
                    sleepMs = wait * 1000L
                    AppLog.add("Rolimons просит не спешить (429). Пауза $wait сек.")
                } else {
                    backoff = 0
                }
            } catch (e: InterruptedException) {
                return
            } catch (e: Exception) {
                AppLog.add("Ошибка: ${e.message}")
            }
            tick++
            try { Thread.sleep(sleepMs) } catch (e: InterruptedException) { return }
        }
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        AppLog.add("Сервис остановлен")
        super.onDestroy()
    }
}
