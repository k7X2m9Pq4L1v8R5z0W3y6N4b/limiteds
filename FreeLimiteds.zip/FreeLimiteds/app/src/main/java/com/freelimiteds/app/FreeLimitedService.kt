package com.freelimiteds.app

import android.app.Service
import android.content.Intent
import android.os.IBinder

class FreeLimitedService : Service() {
    @Volatile private var running = false
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifier.ensureChannels(this)
        startForeground(1, Notifier.foreground(this))
        if (!running) {
            running = true
            worker = Thread { loop() }.also { it.start() }
            AppLog.add("Сервис запущен")
        }
        return START_STICKY
    }

    private fun loop() {
        var tick = 0
        while (running) {
            try {
                // Rolimons опрашиваем реже (каждый 3-й цикл), чтобы не нагружать сайт
                val res = Sources.fetch(includeRolimons = tick % 3 == 0)
                res.errors.forEach { AppLog.add("⚠ $it") }

                if (res.okSources > 0) {
                    val seen = Store.seen(this)
                    val fresh = res.items.filter { it.id.toString() !in seen }
                    if (fresh.isNotEmpty()) {
                        Store.addSeen(this, fresh.map { it.id })
                        if (Store.seeded(this)) {
                            fresh.forEach {
                                Notifier.notifyItem(this, it)
                                AppLog.add("🆓 НОВАЯ: ${it.name} ${it.url}")
                            }
                        } else {
                            AppLog.add("Первый запуск: запомнил ${fresh.size} уже существующих")
                        }
                    }
                    Store.setSeeded(this)
                }
            } catch (e: InterruptedException) {
                return
            } catch (e: Exception) {
                AppLog.add("Ошибка: ${e.message}")
            }
            tick++
            try { Thread.sleep(10_000) } catch (e: InterruptedException) { return }
        }
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        AppLog.add("Сервис остановлен")
        super.onDestroy()
    }
}
