package com.freelimiteds.app

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class Item(
    val id: Long,
    val name: String,
    val url: String,
    val source: String,
    val needsCheck: Boolean = false,   // нужно открыть страницу предмета на Rolimons и проверить
    val trustedFree: Boolean = false,  // предмет со страницы «бесплатные» — цену не перепроверяем
    val extra: String = ""             // цена / где продаётся / тираж
)

class FetchResult(
    val items: List<Item>,
    val errors: List<String>,
    val rateLimitedSec: Int,     // -1 = лимита от Rolimons нет
    val rolimonsAll: Boolean,    // обе страницы Rolimons успешно загружены
    val info: List<String>
)

class RateLimitException(val retryAfterSec: Int, msg: String) : RuntimeException(msg)

object Sources {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private const val UA =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    private fun get(url: String): String {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        client.newCall(req).execute().use { r ->
            if (r.code == 429) {
                val ra = r.header("Retry-After")?.trim()?.toIntOrNull() ?: 0
                throw RateLimitException(ra, "429 (лимит запросов)")
            }
            if (!r.isSuccessful) throw RuntimeException("HTTP ${r.code}")
            return r.body?.string() ?: ""
        }
    }

    // ================= Rolimons (основной источник) =================
    private const val FREE_URL = "https://www.rolimons.com/free-roblox-limiteds"
    private const val NEW_URL = "https://www.rolimons.com/marketplace/new"
    private val idRe = Regex("data-item-id=\"(\\d+)\"")

    private fun pageItems(url: String, label: String, trusted: Boolean, info: MutableList<String>): List<Item> {
        val html = get(url)
        val start = html.indexOf("id=\"page_content_body\"")
        val body = if (start >= 0) html.substring(start) else html
        val ids = idRe.findAll(body).map { it.groupValues[1].toLong() }.distinct().toList()
        info += "Rolimons $label: страница ${html.length} байт, предметов: ${ids.size}"
        return ids.map {
            Item(it, "Предмет #$it", "https://www.roblox.com/catalog/$it", "Rolimons",
                needsCheck = true, trustedFree = trusted)
        }
    }

    private fun field(html: String, label: String): String {
        val re = Regex(">\\s*$label\\s*</div>\\s*<div[^>]*>\\s*(.*?)\\s*</div>", RegexOption.DOT_MATCHES_ALL)
        return re.find(html)?.groupValues?.get(1)
            ?.replace(Regex("<[^>]+>"), "")?.replace(Regex("\\s+"), " ")?.trim() ?: ""
    }

    /** Открывает страницу предмета на Rolimons. null = не бесплатный или продаётся не в каталоге. */
    fun resolve(item: Item): Item? {
        val html = get("https://www.rolimons.com/item/${item.id}")
        val price = field(html, "Price")
        val loc = field(html, "Sale Location")
        val qty = field(html, "Total Quantity")
        val title = Regex("<title>(.*?)</title>", RegexOption.DOT_MATCHES_ALL)
            .find(html)?.groupValues?.get(1)?.substringBefore("|")?.trim().orEmpty()

        val free = item.trustedFree || price.contains("free", true) || price.filter { it.isDigit() } == "0"
        val onlyInGames = loc.contains("experience", true) &&
            !loc.contains("marketplace", true) && !loc.contains("catalog", true) && !loc.contains("shop", true)
        if (!free || onlyInGames) return null

        val extra = listOf(
            if (price.isNotEmpty()) "Цена: $price" else "",
            if (loc.isNotEmpty()) "Где: $loc" else "",
            if (qty.isNotEmpty()) "Тираж: $qty" else ""
        ).filter { it.isNotEmpty() }.joinToString(" • ")
        return item.copy(name = title.ifEmpty { item.name }, needsCheck = false, extra = extra)
    }

    // ================= Каталог Roblox (дополнительный источник) =================
    private const val ROBLOX_URL =
        "https://catalog.roblox.com/v1/search/items/details?Category=1&SortType=3&MaxPrice=0&Limit=60"
    private val limitedTypes = setOf("Collectible", "Limited", "LimitedUnique")
    private var robloxBlockedUntil = 0L
    private var robloxBackoff = 0

    private fun isFreeLimited(o: JSONObject): Boolean {
        val r = o.optJSONArray("itemRestrictions") ?: return false
        var limited = false
        for (i in 0 until r.length()) if (r.optString(i) in limitedTypes) limited = true
        if (!limited) return false
        if (o.isNull("price") || o.optLong("price", -1) != 0L) return false
        if (!o.optBoolean("isPurchasable", true)) return false
        val loc = o.optJSONObject("saleLocation")?.optString("saleLocationType") ?: ""
        return loc.isEmpty() || loc.contains("Shop")
    }

    private fun roblox(info: MutableList<String>): List<Item> {
        val arr = JSONObject(get(ROBLOX_URL)).optJSONArray("data") ?: return emptyList()
        val out = mutableListOf<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (!isFreeLimited(o)) continue
            val id = o.getLong("id")
            out += Item(id, o.optString("name", "?"), "https://www.roblox.com/catalog/$id", "Roblox",
                extra = "Цена: 0")
        }
        info += "Roblox: получено ${arr.length()}, бесплатных лимиток ${out.size}"
        return out
    }

    /**
     * Каждый цикл: страница «бесплатные лимитки» Rolimons.
     * Каждый 3-й цикл (раз в минуту): ещё «новые на маркетплейсе» Rolimons и каталог Roblox.
     */
    fun fetch(tick: Int): FetchResult {
        val found = LinkedHashMap<Long, Item>()
        val errors = mutableListOf<String>()
        val info = mutableListOf<String>()
        var rl = -1
        var rolimonsOk = 0
        val full = tick % 3 == 0

        // Roblox первым: его предметы уже проверены и с названиями
        if (full && System.currentTimeMillis() >= robloxBlockedUntil) {
            try {
                roblox(info).forEach { found.putIfAbsent(it.id, it) }
                robloxBackoff = 0
            } catch (e: RateLimitException) {
                robloxBackoff = if (robloxBackoff == 0) 60 else minOf(robloxBackoff * 2, 300)
                val wait = maxOf(robloxBackoff, e.retryAfterSec)
                robloxBlockedUntil = System.currentTimeMillis() + wait * 1000L
                errors += "Roblox 429, пропускаю его $wait сек. (Rolimons работает как обычно)"
            } catch (e: Exception) {
                errors += "Roblox: ${e.message}"
            }
        }

        try {
            pageItems(FREE_URL, "бесплатные", true, info).forEach { found.putIfAbsent(it.id, it) }
            rolimonsOk++
        } catch (e: RateLimitException) { rl = maxOf(rl, e.retryAfterSec) }
        catch (e: Exception) { errors += "Rolimons (бесплатные): ${e.message}" }

        if (full) {
            try {
                pageItems(NEW_URL, "новые", false, info).forEach { found.putIfAbsent(it.id, it) }
                rolimonsOk++
            } catch (e: RateLimitException) { rl = maxOf(rl, e.retryAfterSec) }
            catch (e: Exception) { errors += "Rolimons (новые): ${e.message}" }
        }

        return FetchResult(found.values.toList(), errors, rl, full && rolimonsOk == 2, info)
    }
}
