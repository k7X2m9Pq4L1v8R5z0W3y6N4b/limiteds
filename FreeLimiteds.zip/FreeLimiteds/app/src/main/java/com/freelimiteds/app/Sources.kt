package com.freelimiteds.app

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class Item(val id: Long, val name: String, val url: String, val source: String)

class FetchResult(val items: List<Item>, val errors: List<String>, val okSources: Int)

object Sources {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private const val UA =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    private fun get(url: String): String {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        client.newCall(req).execute().use { r ->
            if (r.code == 429) throw RuntimeException("429 (лимит запросов): $url")
            if (!r.isSuccessful) throw RuntimeException("HTTP ${r.code}: $url")
            return r.body?.string() ?: ""
        }
    }

    // ---------- Источник 1: каталог Roblox (маркетплейс) ----------
    private val robloxUrls = listOf(
        "https://catalog.roblox.com/v1/search/items/details?Category=1&SortType=3&Limit=30",
        "https://catalog.roblox.com/v1/search/items/details?Category=1&SortType=3&MaxPrice=0&Limit=30"
    )
    private val limitedTypes = setOf("Collectible", "Limited", "LimitedUnique")

    private fun isFreeLimited(o: JSONObject): Boolean {
        val r = o.optJSONArray("itemRestrictions") ?: return false
        var limited = false
        for (i in 0 until r.length()) if (r.optString(i) in limitedTypes) limited = true
        if (!limited) return false
        if (o.isNull("price") || o.optLong("price", -1) != 0L) return false
        if (!o.optBoolean("isPurchasable", true)) return false
        // только каталог, не предметы «только в плейсах»
        val loc = o.optJSONObject("saleLocation")?.optString("saleLocationType") ?: ""
        return loc.isEmpty() || loc.contains("Shop")
    }

    fun roblox(): List<Item> {
        val out = mutableListOf<Item>()
        for (u in robloxUrls) {
            val arr = JSONObject(get(u)).optJSONArray("data") ?: continue
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (!isFreeLimited(o)) continue
                val id = o.getLong("id")
                out += Item(id, o.optString("name", "?"), "https://www.roblox.com/catalog/$id", "Roblox")
            }
        }
        return out
    }

    // ---------- Источник 2: страница Rolimons ----------
    fun rolimons(): List<Item> {
        val html = get("https://www.rolimons.com/free-roblox-limiteds")
        return Regex("""/item/(\d+)""").findAll(html)
            .map { it.groupValues[1].toLong() }
            .distinct()
            .map { Item(it, "Предмет #$it", "https://www.rolimons.com/item/$it", "Rolimons") }
            .toList()
    }

    fun fetch(includeRolimons: Boolean): FetchResult {
        val found = LinkedHashMap<Long, Item>()
        val errors = mutableListOf<String>()
        var ok = 0
        try { roblox().forEach { found.putIfAbsent(it.id, it) }; ok++ }
        catch (e: Exception) { errors += "Roblox: ${e.message}" }
        if (includeRolimons) {
            try { rolimons().forEach { found.putIfAbsent(it.id, it) }; ok++ }
            catch (e: Exception) { errors += "Rolimons: ${e.message}" }
        }
        return FetchResult(found.values.toList(), errors, ok)
    }
}
