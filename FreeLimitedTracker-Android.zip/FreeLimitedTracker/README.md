# Free Limited Tracker (Android prototype)

A minimal Android app that periodically queries Roblox's public catalog search endpoint while the app is open.

## Build with GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this ZIP to the repository root (not the ZIP file itself).
3. Push to the `main` branch, or open **Actions → Build Android APK → Run workflow**.
4. Open the completed workflow run and download the `FreeLimitedTracker-debug` artifact.
5. Extract the artifact ZIP; install `app-debug.apk` on Android.

## Notes
- This is an experimental prototype, not an official Roblox or Rolimon's app.
- It checks only the first 30 results returned by the public catalog endpoint, every 60 seconds.
- Roblox may change, throttle, or delay this endpoint; therefore the app cannot guarantee real-time discovery or detection ahead of Rolimon's.
- Scanning runs only while the app process is alive and the screen/app is kept active. It does not yet run as a background service or send system notifications.
- No Roblox login, password, cookie, or account access is required.
