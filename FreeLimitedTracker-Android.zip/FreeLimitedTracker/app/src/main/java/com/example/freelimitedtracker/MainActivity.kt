package com.example.freelimitedtracker

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private var pollingTask: ScheduledFuture<*>? = null
    private val seenIds = mutableSetOf<String>()
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private var checks = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        appendLog("Готово к запуску. Сканирование работает, пока приложение открыто.")
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 24)
        }

        val title = TextView(this).apply {
            text = "Free Limited Tracker"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
        }
        outer.addView(title)

        status = TextView(this).apply {
            text = "Статус: остановлен"
            textSize = 16f
            setPadding(0, 18, 0, 18)
        }
        outer.addView(status)

        startButton = Button(this).apply {
            text = "Начать сканирование"
            setOnClickListener { startScanning() }
        }
        outer.addView(startButton)

        stopButton = Button(this).apply {
            text = "Остановить"
            isEnabled = false
            setOnClickListener { stopScanning() }
        }
        outer.addView(stopButton)

        val note = TextView(this).apply {
            text = "Источник: публичная выдача каталога Roblox. Это экспериментальная версия: она не гарантирует обнаружение предметов раньше Rolimon's."
            textSize = 13f
            setPadding(0, 12, 0, 16)
        }
        outer.addView(note)

        val scroll = ScrollView(this)
        log = TextView(this).apply {
            textSize = 14f
            setTextIsSelectable(true)
        }
        scroll.addView(log)
        outer.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(outer)
    }

    private fun startScanning() {
        if (pollingTask != null) return
        startButton.isEnabled = false
        stopButton.isEnabled = true
        status.text = "Статус: сканирование..."
        appendLog("Запущено. Интервал проверки — 60 секунд.")
        pollingTask = executor.scheduleWithFixedDelay({
            scanOnce()
        }, 0, 60, TimeUnit.SECONDS)
    }

    private fun stopScanning() {
        pollingTask?.cancel(false)
        pollingTask = null
        startButton.isEnabled = true
        stopButton.isEnabled = false
        status.text = "Статус: остановлен"
        appendLog("Сканирование остановлено.")
    }

    private fun scanOnce() {
        try {
            val url = URL(
                "https://catalog.roblox.com/v1/search/items/details" +
                    "?Category=2&SortType=3&Limit=30&MaxPrice=0"
            )
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15000
                readTimeout = 15000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "FreeLimitedTracker/0.1")
            }

            val code = connection.responseCode
            if (code !in 200..299) {
                throw IllegalStateException("Roblox API ответил HTTP $code")
            }

            val body = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            val data = JSONObject(body).optJSONArray("data")
                ?: throw IllegalStateException("В ответе нет массива data")

            val found = mutableListOf<String>()
            for (i in 0 until data.length()) {
                val item = data.optJSONObject(i) ?: continue
                val id = item.optString("id", "")
                if (id.isBlank()) continue

                val restrictions = item.optJSONArray("itemRestrictions")
                var limitedUnique = false
                if (restrictions != null) {
                    for (j in 0 until restrictions.length()) {
                        if (restrictions.optString(j) == "LimitedUnique") {
                            limitedUnique = true
                        }
                    }
                }

                val priceFree = item.has("price") && item.isNull("price").not() &&
                    item.optDouble("price", -1.0) == 0.0
                val statusFree = item.optString("priceStatus") == "Free"

                if (limitedUnique && (priceFree || statusFree) && seenIds.add(id)) {
                    val name = item.optString("name", "Без названия")
                    val stock = if (item.has("unitsAvailableForConsumption"))
                        item.optString("unitsAvailableForConsumption")
                    else "неизвестно"
                    found.add("🔥 НОВАЯ FREE LIMITED\n$name\nID: $id\nОстаток: $stock\nhttps://www.roblox.com/catalog/$id")
                }
            }

            checks++
            runOnUiThread {
                status.text = "Статус: сканирование • проверок: $checks"
                appendLog("Проверка №$checks: получено предметов — ${data.length()}.")
                found.forEach { appendLog(it) }
            }
        } catch (e: Exception) {
            runOnUiThread {
                appendLog("Ошибка проверки: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    private fun appendLog(message: String) {
        runOnUiThread {
            log.append("\n$message\n")
        }
    }

    override fun onDestroy() {
        pollingTask?.cancel(true)
        executor.shutdownNow()
        super.onDestroy()
    }
}
